import App from './App';

export default function Homescreen(){
  return(
    <App/>
  );
}